# OpenClaw 配置系统学习总结

## 📋 问题复盘

### 场景
配置 Brave Search API key，使 `web_search` 工具正常工作。

### 我的错误配置
```json
// ❌ 错误位置: ~/.config/openclaw/config.json
{
  "web": {
    "brave_api_key": "BSACAqN3n2DlHcHTxjxPlu_XPi3nBk_"
  }
}
```

### 正确配置
```json
// ✅ 正确位置: ~/.openclaw/openclaw.json
{
  "tools": {
    "web": {
      "search": {
        "provider": "brave",
        "apiKey": "BSACAqN3n2DlHcHTxjxPlu_XPi3nBk_"
      }
    }
  }
}
```

---

## 🔍 错误分析

| 维度 | 我的配置 | 正确配置 | 说明 |
|------|---------|---------|------|
| **文件位置** | `~/.config/openclaw/config.json` | `~/.openclaw/openclaw.json` | CLI vs Gateway |
| **配置路径** | `web.brave_api_key` | `tools.web.search.apiKey` | 嵌套层级错误 |
| **配置格式** | 扁平化 | 嵌套结构 | 不符合 Schema |
| **读取方式** | CLI 读取 | Gateway 启动时读取 | 运行时依赖 |

---

## 🧠 核心认知

### OpenClaw 双配置系统

```
┌─────────────────────────────────────────────────────────────┐
│                    OpenClaw 架构                            │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌──────────────────────┐    ┌──────────────────────┐      │
│  │   CLI 工具配置        │    │   Gateway 运行配置    │      │
│  │   ~/.config/openclaw/ │    │   ~/.openclaw/       │      │
│  │   config.json         │    │   openclaw.json      │      │
│  ├──────────────────────┤    ├──────────────────────┤      │
│  │ • workspace          │    │ • meta               │      │
│  │ • model              │    │ • models             │      │
│  │ • web (❌ 不生效)     │    │ • agents             │      │
│  │ • tavily (❌ 不生效)  │    │ • tools ✅           │      │
│  │                      │    │   - web.search       │      │
│  │                      │    │   - web.fetch        │      │
│  └──────────────────────┘    └──────────────────────┘      │
│           │                           │                     │
│           ▼                           ▼                     │
│     ┌──────────┐               ┌──────────┐                │
│     │ openclaw │               │ Gateway  │                │
│     │ 命令行   │               │ 守护进程 │                │
│     └──────────┘               └──────────┘                │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### 关键区别

| 配置类型 | 用途 | 读取时机 | 影响范围 |
|---------|------|---------|---------|
| **CLI 配置** | 命令行工具行为 | 执行命令时 | `openclaw` 命令 |
| **Gateway 配置** | 守护进程运行时 | 启动时 | 工具、模型、会话 |

---

## 📚 配置 Schema 详解

### Gateway 配置结构

```json
{
  "meta": {
    "lastTouchedVersion": "2026.2.3-1",
    "lastTouchedAt": "2026-02-07T00:22:00.000Z"
  },
  "models": {
    "mode": "merge",
    "providers": { ... }
  },
  "agents": { ... },
  "tools": {
    "web": {
      "search": {
        "provider": "brave",           // 搜索引擎: brave | perplexity
        "apiKey": "YOUR_API_KEY",      // API 密钥
        "maxResults": 10,              // 最大结果数
        "timeoutSeconds": 30           // 超时时间
      },
      "fetch": {
        "maxCharsCap": 10000,          // 最大字符限制
        "firecrawl": {
          "enabled": false             // Firecrawl 回退
        }
      }
    }
  }
}
```

---

## ✅ 正确配置流程

### 步骤 1: 确定配置类型
```bash
# 需要重启 Gateway 生效？→ 配在 ~/.openclaw/openclaw.json
# 只是 CLI 行为？→ 配在 ~/.config/openclaw/config.json
```

### 步骤 2: 修改 Gateway 配置
```bash
# 备份原配置
cp ~/.openclaw/openclaw.json ~/.openclaw/openclaw.json.bak

# 编辑配置（使用 python 确保格式正确）
cat ~/.openclaw/openclaw.json | python3 -c "
import json, sys
data = json.load(sys.stdin)

# 添加/修改 web search 配置
data['tools'] = data.get('tools', {})
data['tools']['web'] = data['tools'].get('web', {})
data['tools']['web']['search'] = {
    'provider': 'brave',
    'apiKey': 'YOUR_API_KEY'
}

print(json.dumps(data, indent=2))
" > ~/.openclaw/openclaw.json.new

# 验证并替换
mv ~/.openclaw/openclaw.json.new ~/.openclaw/openclaw.json
```

### 步骤 3: 重启 Gateway
```bash
# 停止 Gateway
pkill -f "openclaw-gateway"

# 启动 Gateway
openclaw gateway start

# 验证
pgrep -f "openclaw-gateway"
```

### 步骤 4: 测试
```bash
# 使用 web_search 工具测试
openclaw web_search "test query" --count 3
```

---

## 🔧 常见工具配置

### Tavily Search
```json
{
  "tools": {
    "web": {
      "search": {
        "provider": "tavily",
        "apiKey": "tvly-xxx"
      }
    }
  }
}
```

### Perplexity Search
```json
{
  "tools": {
    "web": {
      "search": {
        "provider": "perplexity",
        "apiKey": "pplx-xxx"
      }
    }
  }
}
```

### Firecrawl (web_fetch 回退)
```json
{
  "tools": {
    "web": {
      "fetch": {
        "firecrawl": {
          "enabled": true,
          "apiKey": "fc-xxx"
        }
      }
    }
  }
}
```

---

## ⚠️ 常见错误

| 错误 | 原因 | 解决 |
|------|------|------|
| `missing_brave_api_key` | 配置在 CLI 而非 Gateway | 移到 `~/.openclaw/openclaw.json` |
| `403 Forbidden` | API key 无效或受限 | 检查 key 状态，或更换 key |
| 配置不生效 | 未重启 Gateway | 重启后加载新配置 |
| 格式错误 | JSON 语法错误 | 使用 python 验证格式 |

---

## 📝 检查清单

配置新工具时：
- [ ] 确定是 Gateway 工具还是 CLI 功能
- [ ] 修改正确的配置文件
- [ ] 使用正确的配置路径
- [ ] 验证 JSON 格式
- [ ] 重启 Gateway
- [ ] 测试工具是否正常工作

---

## 💡 关键教训

1. **Gateway 工具配在 Gateway 配置里**
   - `web_search`, `web_fetch` 是 Gateway 工具
   - 必须配在 `~/.openclaw/openclaw.json`

2. **配置后必须重启 Gateway**
   - Gateway 启动时读取配置
   - 运行时不会自动重载

3. **区分 CLI 和 Gateway**
   - CLI: `openclaw` 命令
   - Gateway: 守护进程，运行工具

4. **验证配置格式**
   - 使用 `python3 -m json.tool` 验证
   - 避免手动编辑导致的语法错误

---

*学习总结时间: 2026-02-07 08:25*
*教训来源: Brave API 配置失败复盘*
